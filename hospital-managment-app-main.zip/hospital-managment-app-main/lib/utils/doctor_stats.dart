const doctorStats = [
  {
    "title": "Patients",
    "number":"650+",
    "image":"assets/icons/patient.png"
  },
  {
    "title": "Years expert",
    "number":"11+",
    "image":"assets/icons/experience.png"
  },
  {
    "title": "Rating",
    "number":"5.0",
    "image":"assets/icons/rating.png"
  },
  {
    "title": "Reviews",
    "number":"300+",
    "image":"assets/icons/review.png"
  },
];
