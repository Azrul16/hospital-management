final medicationList = [
  {
    "name": 'Ocysius',
    "dailyDose": "Two times Daily",
    "startTime": "08:00AM",
    "endTime": "09:00PM",
  },
];
