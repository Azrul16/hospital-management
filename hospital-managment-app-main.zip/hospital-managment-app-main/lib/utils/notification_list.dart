final notificationList = [
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
  {
    "date": "Juin 2024",
    "details": "You have an appointment at 10:30pm ",
    "icon": "assets/icons/notif-bell.png",
  },
];
